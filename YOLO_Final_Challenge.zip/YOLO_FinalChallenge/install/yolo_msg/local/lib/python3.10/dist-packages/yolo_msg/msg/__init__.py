from yolo_msg.msg._inference_result import InferenceResult  # noqa: F401
from yolo_msg.msg._yolov8_inference import Yolov8Inference  # noqa: F401
