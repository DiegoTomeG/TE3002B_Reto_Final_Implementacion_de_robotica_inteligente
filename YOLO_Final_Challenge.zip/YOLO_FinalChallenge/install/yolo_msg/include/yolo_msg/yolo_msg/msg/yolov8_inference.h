// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msg:msg/Yolov8Inference.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSG__MSG__YOLOV8_INFERENCE_H_
#define YOLO_MSG__MSG__YOLOV8_INFERENCE_H_

#include "yolo_msg/msg/detail/yolov8_inference__struct.h"
#include "yolo_msg/msg/detail/yolov8_inference__functions.h"
#include "yolo_msg/msg/detail/yolov8_inference__type_support.h"

#endif  // YOLO_MSG__MSG__YOLOV8_INFERENCE_H_
