// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msg:msg/InferenceResult.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSG__MSG__INFERENCE_RESULT_H_
#define YOLO_MSG__MSG__INFERENCE_RESULT_H_

#include "yolo_msg/msg/detail/inference_result__struct.h"
#include "yolo_msg/msg/detail/inference_result__functions.h"
#include "yolo_msg/msg/detail/inference_result__type_support.h"

#endif  // YOLO_MSG__MSG__INFERENCE_RESULT_H_
