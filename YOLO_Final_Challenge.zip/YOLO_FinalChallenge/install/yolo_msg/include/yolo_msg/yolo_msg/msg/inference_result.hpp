// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_MSG__MSG__INFERENCE_RESULT_HPP_
#define YOLO_MSG__MSG__INFERENCE_RESULT_HPP_

#include "yolo_msg/msg/detail/inference_result__struct.hpp"
#include "yolo_msg/msg/detail/inference_result__builder.hpp"
#include "yolo_msg/msg/detail/inference_result__traits.hpp"

#endif  // YOLO_MSG__MSG__INFERENCE_RESULT_HPP_
