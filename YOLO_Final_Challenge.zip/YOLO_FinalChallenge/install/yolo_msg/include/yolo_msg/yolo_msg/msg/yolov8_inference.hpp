// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_MSG__MSG__YOLOV8_INFERENCE_HPP_
#define YOLO_MSG__MSG__YOLOV8_INFERENCE_HPP_

#include "yolo_msg/msg/detail/yolov8_inference__struct.hpp"
#include "yolo_msg/msg/detail/yolov8_inference__builder.hpp"
#include "yolo_msg/msg/detail/yolov8_inference__traits.hpp"

#endif  // YOLO_MSG__MSG__YOLOV8_INFERENCE_HPP_
