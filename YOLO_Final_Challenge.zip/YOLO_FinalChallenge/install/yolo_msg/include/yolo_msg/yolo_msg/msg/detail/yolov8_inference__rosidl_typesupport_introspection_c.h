// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from yolo_msg:msg/Yolov8Inference.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSG__MSG__DETAIL__YOLOV8_INFERENCE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define YOLO_MSG__MSG__DETAIL__YOLOV8_INFERENCE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "yolo_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_yolo_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, yolo_msg, msg, Yolov8Inference)();

#ifdef __cplusplus
}
#endif

#endif  // YOLO_MSG__MSG__DETAIL__YOLOV8_INFERENCE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
